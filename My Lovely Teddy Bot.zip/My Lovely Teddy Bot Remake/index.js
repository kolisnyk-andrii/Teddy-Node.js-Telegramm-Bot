// Bot vonf
const TelegramBot = require('node-telegram-bot-api');

const token = '8132013669:AAGwL4hgw53wUWf2Sr72quvXjIm17Px3J0Q';
const weatherApiKey = '03493f3917ba42202dd24f29c034f8da';

const bot = new TelegramBot(token, {polling: true});

// consts, lets, functions...
const login = "12";
let isLogin = false;

// Bot say
const botOnText = 
`*So, what i can do?*

*Basic:*
/info - To see information about me ℹ
/login (LOGIN PASSWORD) - To login in your *Bear* account 🐻
/loginStatus - To check your login status 🏷

*Bear:*
/BTeddy - To speak with me 🧸
/BMotivation - I say to you random motivation phrase 🤯
/BWeather - To show weather in your region ☀
/BTime - To show time in your region ⏰
`;

const botInfoText =
`Hi, i am *Teddy* 🧸

I am here to make
your life better! ✨

Injoy and have fun
using me 🎉
`;

const botInDeveloping =
`_I am sorry, but this part is in developing_ 🛠
`;

const botRandomStartText =
[
    "Do *NOT* write '/start' 😤",
    "I hate '/start' 😣",
    "Please, don't 🤬",
    "'/start' is stupid 😒",
    "NO NO NO NO NOT '/start' 🛑"
];

const botRandomMotivationPhrases =
[
    "*“All our dreams can come true, if we have the courage to pursue them.” —Walt Disney*",
    "*“The secret of getting ahead is getting started.” —Mark Twain*",
    "*“I’ve missed more than 9,000 shots in my career. I’ve lost almost 300 games. Twenty-six times I’ve been trusted to take the game-winning shot and missed. I’ve failed over and over and over again in my life, and that is why I succeed.” —Michael Jordan*",
    "*“We cannot solve problems with the kind of thinking we employed when we came up with them.” —Albert Einstein *",
    "*“He who conquers himself is the mightiest warrior.” —Confucius*"
];

// Bot
bot.on('message', (msg) =>
{
    const chatId = msg.chat.id;
    const say = msg.text;
    const opts = {parse_mode: 'Markdown'};

    if (say !== "/info" && say !== "/loginStatus" && say !== "/BTeddy" && say !== "/BMotivation" && say !== "/BWeather"
    && say !== "/BTime" && say !== `/login ${login}`)
    {
        bot.sendMessage(chatId, botOnText, opts);
    }
});

// Bot commands
// Start
let startFlag = 0;

bot.onText(/\/start/, (msg) =>
{
    const chatId = msg.chat.id;
    const opts = {parse_mode: 'Markdown'};
    let botSRS = Math.floor(Math.random() * botRandomStartText.length);

    if (startFlag > 0)
    {
        bot.sendMessage(chatId, botRandomStartText[botSRS], opts);
    }
    startFlag += 1;
});

// Info
bot.onText(/\/info/, (msg) =>
{
    const chatId = msg.chat.id;
    const opts = {parse_mode: 'Markdown'};

    bot.sendMessage(chatId, botInfoText, opts);
});

// Login
bot.onText(/\/login (.+)/, (msg, match) =>
{
    const chatId = msg.chat.id;
    const resp = match[1];
    const opts = {parse_mode: 'Markdown'};

    if (resp === login)
    {
        isLogin = true;
        bot.sendMessage(chatId, "*Login secsess.* To check your login status write /loginStatus 🏆", opts);
    }
    else
    {
        isLogin = false;
        bot.sendMessage(chatId, "*Sorry, but your login or password is wrong* 😟", opts);
    }
});

// Login Status
bot.onText(/\/loginStatus/, (msg) =>
{
    const chatId = msg.chat.id;
    const opts = {parse_mode: 'Markdown'};

    if (isLogin)
    {
        bot.sendMessage(chatId, "Login status: *You are bear* 🐻", opts);
    }
    else
    {
        bot.sendMessage(chatId, "Login status: *none*", opts);
    }
});

// BTeddy
bot.onText(/\/BTeddy/, (msg) =>
{
    const chatId = msg.chat.id;
    const opts = {parse_mode: 'Markdown'};

    bot.sendMessage(chatId, botInDeveloping, opts);
});

// BMotivation
bot.onText(/\/BMotivation/, (msg) =>
{
    const chatId = msg.chat.id;
    const opts = {parse_mode: 'Markdown'};
    let randomMotivationPhrase = Math.floor(Math.random() * botRandomMotivationPhrases.length);
    
    bot.sendMessage(chatId, botRandomMotivationPhrases[randomMotivationPhrase], opts);
});

//BWeather
bot.onText(/\/BWeather/, (msg) =>
{
    const chatId = msg.chat.id;
    const opts = {parse_mode: 'Markdown'};

    bot.sendMessage(chatId, botInDeveloping, opts);
});

//BTime
bot.onText(/\/BTime/, (msg) =>
{
    const chatId = msg.chat.id;
    const opts = {parse_mode: 'Markdown'};

    bot.sendMessage(chatId, botInDeveloping, opts);
});